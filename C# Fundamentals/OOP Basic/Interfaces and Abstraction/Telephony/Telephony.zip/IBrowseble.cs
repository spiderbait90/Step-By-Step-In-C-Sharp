﻿internal interface IBrowseble
{
    string Browse(string site);
}