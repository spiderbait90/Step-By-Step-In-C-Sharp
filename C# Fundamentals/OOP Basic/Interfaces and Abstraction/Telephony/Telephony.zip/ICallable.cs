﻿public interface ICallable
{
    string Call(string num);
}